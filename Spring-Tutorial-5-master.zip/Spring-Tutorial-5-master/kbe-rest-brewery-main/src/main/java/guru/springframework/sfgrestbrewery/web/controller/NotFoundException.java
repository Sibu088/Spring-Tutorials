package guru.springframework.sfgrestbrewery.web.controller;

// Custom exception to signal "Not Found" errors
public class NotFoundException extends RuntimeException {
}
