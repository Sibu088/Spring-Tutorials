package guru.springframework.sfgrestbrewery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KbeRestBrewery {

	public static void main(String[] args) {
		SpringApplication.run(KbeRestBrewery.class, args);
	}

}
