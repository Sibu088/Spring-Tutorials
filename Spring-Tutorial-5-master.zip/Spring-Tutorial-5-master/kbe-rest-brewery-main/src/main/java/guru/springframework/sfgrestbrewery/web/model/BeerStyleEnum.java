package guru.springframework.sfgrestbrewery.web.model;


// List of possible beer styles
public enum BeerStyleEnum {
    LAGER, PILSNER, STOUT, GOSE, PORTER, ALE, WHEAT, IPA, PALE_ALE, SAISON
}